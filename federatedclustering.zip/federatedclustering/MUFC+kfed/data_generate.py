from utils import *
import os
os.environ["OMP_NUM_THREADS"] = '8'
dataname='iris'
pathData = '../dataset/'+dataname+'.txt'
data: ndarray = loadtxt(pathData)
label = data[:, -1]
data: ndarray = data[:, :-1]
num_clients=10
data2=split_data(data,
               num_clusters=5,
               num_clients=num_clients,
               split='non-iid',
               k_prime=2)
#之前的客户端数量，这里需要匹配。
order=[]
allable=[]
for i_client in range(num_clients):
    eachlabel=[]
    each=data2["client_" + str(i_client)]
    index = find_index(data, each)
    for j in index:
        eachlabel.append(label[j])
    allable.append(eachlabel)
    order.append(index)

#data2['kmeans_loss']=data2['kmeans_loss']
data2['full_data']=data
data2['true_label']=label
data2['num_clusters']=10
data2['order']=order
data2['eachlable']=allable
# 保存为pkl
with open('../dataset/newpkl/'+dataname+'fed.pkl', 'wb') as f:
    # 将对象序列化到文件中
    pickle.dump(data2, f)
print(dataname,'数据构造完成，','data generation finish')



